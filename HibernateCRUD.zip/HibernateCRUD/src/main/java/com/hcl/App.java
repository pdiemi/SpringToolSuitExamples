package com.hcl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class App {
	public static void main(String[] args) {
		 App a1=new App();
		 
		Emp e1=new Emp();
		e1.setEmpId(111L);e1.setEmpName("Sam");e1.setEmpSal(1234);
		a1.saveEmp(e1);
		Emp e2=new Emp();
		e2.setEmpId(112L);e2.setEmpName("Tom");e2.setEmpSal(5555);
		Emp e3=new Emp();
		e3.setEmpId(113L);e3.setEmpName("Delete");e3.setEmpSal(6666);
		a1.saveEmp(e2);a1.saveEmp(e3);
	   	a1.listEmp();
		//a1.updateEmp(111L,"TEST", 8888);
		a1.deleteEmp(e3);
		a1.listEmp();
		
	}

	public void saveEmp(Emp emp) {
		Session session = HibUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			 session.save(emp);
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			;
		} finally {
			session.close();
		}

	}

	public long listEmp() {
		Session session = HibUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		long eno = 0;
		try {
			transaction = session.beginTransaction();
			List<Emp> list = session.createQuery("from Emp").list(); //HQL Hibernate query language
			//Java 7
			for(Emp temp:list) {
				System.out.println(temp);
			}
			// Java 8  
			list.forEach(System.out::println);//:: method reference
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			;
		} finally {
			session.close();
		}
		return eno;
	}

	public void updateEmp(long eno, String ename, int esal) {
		Session session = HibUtil.getSessionFactory().openSession();
		Transaction transaction = null;

		try {
			transaction = session.beginTransaction();
			Emp update = session.get(Emp.class, eno);
			update.setEmpName(ename);
			update.setEmpSal(esal);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	public void deleteEmp(Emp emp) {
		Session session = HibUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.delete(emp);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
	}
}
