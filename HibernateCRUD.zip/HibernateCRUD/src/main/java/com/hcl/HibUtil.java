package com.hcl;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibUtil {
	 private static SessionFactory sfactory;
	 
	 
	 static {
		 try {
		 StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure().build();
		    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
		    
		     sfactory=meta.getSessionFactoryBuilder().build();
		 }catch(Exception e) {e.printStackTrace();}
	 }
	
public static SessionFactory getSessionFactory() {
	return sfactory;
}
}
